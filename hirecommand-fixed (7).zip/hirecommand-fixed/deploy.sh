#!/bin/bash
set -e

PAT="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"
GITHUB_USER="Advisor25"
GITHUB_REPO="HireCommand"
DB_URL="postgresql://postgres:Advisors25_!@db.rssevzyqvavwfxsryhbr.supabase.co:5432/postgres"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  HireCommand Full Deploy"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

echo ""
echo "▶ Step 1/2 — Pushing schema to Supabase..."
export DATABASE_URL="$DB_URL"
npx drizzle-kit push --force
echo "  ✓ Supabase schema up to date"

echo ""
echo "▶ Step 2/2 — Pushing code to GitHub..."
REMOTE_URL="https://${GITHUB_USER}:${PAT}@github.com/${GITHUB_USER}/${GITHUB_REPO}.git"
git remote set-url origin "$REMOTE_URL" 2>/dev/null || git remote add origin "$REMOTE_URL"
git add -A
git commit -m "Full fix: real stats, email journaling, staleTime, hardcoded keys removed, build fix" 2>/dev/null || echo "  (nothing new to commit)"
git push origin main --force
echo "  ✓ GitHub push complete"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  ✅  Done! Render auto-deploys in ~2 min."
echo "  App: https://hirecommand.onrender.com"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
